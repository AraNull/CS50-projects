#include <cs50.h>
#include <stdio.h>

int main(void)
{
    int n;
    //loop to get the height, in a specific range
    do
    {
        n = get_int("Height: ");
    }
    while (1 > n || n > 8);

    // loop to print rows
    for (int i = 1; i <= n; i++)
    {
        // loop to print spaces
        for (int z = n - i; z > 0; z--)
        {
            printf(" ");
        }
        //loop to print #s
        for (int j = 1; j <= i; j++)
        {
            printf("#");
        }
        printf("\n");
    }
}