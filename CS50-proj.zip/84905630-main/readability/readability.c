#include <cs50.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <math.h>

// Function prototypes
int count_sentences(string text);
int count_letters(string text);
int count_words(string text);

int main(void)
{
    string Text = get_string("Text: ");
    float L = 0;
    float S = 0;
    int W = 0;

    // Get number of words
    W = count_words(Text);
    // Calculate average letters & sentences per 100 words
    L = (float)count_letters(Text) * 100 / W;
    S = (float)count_sentences(Text) * 100 / W;

    // Grade calculation
    float grade = 0.0588 * L - 0.296 * S - 15.8;

    // Output
    if (grade < 1)
    {
        printf("Before Grade 1\n");
    }
    else if (grade < 16)
    {
        printf("Grade %d\n", (int)round(grade));
    }
    else
    {
        printf("Grade 16+\n");
    }

}

// function for counting letters
int count_letters(string text)
{
    int letters = 0;
    for (int i = 0, len = strlen(text); i < len; i++)
    {
        // letters must be alphabets
        if (isalpha(text[i]))
        {
            letters += 1;
        }
    }
    return letters;
}

// function for counting words
int count_words(string text)
{
    int words = 0;
    for (int i = 0, len = strlen(text); i < len; i++)
    {
        if (text[i] == ' ')
        {
            words += 1;
        }
    }
    words += 1;
    return words;
}

// function for counting sentences
int count_sentences(string text)
{
    int sentences = 0;
    for (int i = 0, len = strlen(text); i < len; i++)
    {
        if ((text[i] == '.' || text[i] == '?' || text[i] == '!'))
        {
            sentences += 1;
        }
    }
    return sentences;
}