#include <cs50.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

int main(int argc, string argv[])
{
    if (argc > 2)
    {
        printf("Please enter key in single string.\n");
        exit (1);
    }

    if (argc < 2)
    {
        printf("USAGE: ./substitution KEY");
        exit(1);
    }

    int count;
    if (argc == 2)
    {
        string Key = argv[1];
        if (strlen(Key) < 26)
        {
            printf("Key must contain 26 characters.\n");
            exit(1);
        }
        for (int i = 0, k = strlen(Key); i < k; i++)
        {   count = 0;
            for(int j = 0; j < k; j++)
            {
                if (tolower(Key[i]) == tolower(Key[j]))
                {
                    count += 1;
                }
            }
            if (count > 1)
            {
                printf("Invalid Key: No duplicates\n");
                exit(1);
            }
        }



        for (int i = 0, k = strlen(Key); i < k; i++)
        {
            if (!isalpha(Key[i]))
            {
                printf("Key must only contain alphabetic characters.\n");
                exit(1);
            }
        }

        string plain_text = get_string("plaintext: ");
        int l = strlen(plain_text);
        string cipher_text = plain_text;

        for (int i = 0; i < l; i++)
        {

            if (isupper(plain_text[i]))
            {
                cipher_text[i] = toupper(Key[plain_text[i] - 'A']);
            }
            else if (islower(plain_text[i]))
            {
            cipher_text[i] = tolower(Key[plain_text[i] - 'a']);
            }

        }
        printf("ciphertext:%s\n", cipher_text);
    }
    return 0;
}