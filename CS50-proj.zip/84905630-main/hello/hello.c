#include <stdio.h>
#include <cs50.h>

int main(void)
{
    //get name input from user
    string name = get_string("What's your name? ");
    //print name received from user
    printf("hello, %s!\n", name);
}